# Esp32 Nokia 5110 Interfacing and NTP Sync IST Digital Clock
